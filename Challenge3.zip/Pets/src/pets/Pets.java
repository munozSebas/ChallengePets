/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pets;

/**
 *
 * 
 */

/**
@author 6306841
@Due date: 2/21/22

*/


public class Pets implements Comparable <Pets>{
  /**
*
* Description: This method is used to declare our private attributes, to then add to our Pets constructor.
* @param : So we can use the parameters petName, species, age, year, month, day, ownerLast + firstName, and ownerEmail
* No returns or throws.
*/  
    private String petName;
    private String species;
    private int age;
    private int year;
    private int month;
    private int day;
    private String ownerLastName;
    private String ownerFirstName;
    private String ownerEmail;
    

    public Pets(String petName, String species, int age, int year, int month, int day, String ownerLastName, String ownerFirstName, String ownerEmail) {
        this.petName = petName;
        this.species = species;
        this.age = age;
        this.year = year;
        this.month = month;
        this.day = day;
        this.ownerLastName = ownerLastName;
        this.ownerFirstName = ownerFirstName;
        this.ownerEmail = ownerEmail;
    }
    
    /**
*
* Description: If we wish to use attributes from other classes we declare setters and getters. Used from our parameters
* @param in the setters take a parameter and assign it to an attribute
* @return here we are returning our value.
* @throws none
*/
    

    public String getPetName() {
        return petName;
    }

    public void setPetName(String petName) {
        this.petName = petName;
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public String getOwnerLastName() {
        return ownerLastName;
    }

    public void setOwnerLastName(String ownerLastName) {
        this.ownerLastName = ownerLastName;
    }

    public String getOwnerFirstName() {
        return ownerFirstName;
    }

    public void setOwnerFirstName(String ownerFirstName) {
        this.ownerFirstName = ownerFirstName;
    }

    public String getOwnerEmail() {
        return ownerEmail;
    }

    public void setOwnerEmail(String ownerEmail) {
        this.ownerEmail = ownerEmail;
    }
    
    
    /**
*
* Description: When implementing the Comparable method, we must declare a compareTo method, if not we will get 
* an error saying the class is not abstract. So we can sort in this age, in ascending order.
* @param here we are using Pets other, so we can compare to "other" pet.
* @return we are returning in ascending order, so we commence with 1,-1, and end in 0.

*/
    
    public int compareTo (Pets other) 
    {
        // When you sort commencing at 1 it will be in Ascenind order
         if (this.age > other.age)
        {
            return 1;
        }
        else if (this.age< other.age)
        {
            return -1;
        }
        else
        {
            return 0;
        }
        
    }
    
   /**
*
* Description: the toString will be used so it accessed by the main method, so we can actually print the information we want
* 
* @param none
* @return we are returning what we actually want display, so our variables and and actual typed phrases.
* @throws none
*/
    
    
    public String toString()
    {
        return ownerFirstName +"," + ownerLastName + ", your pet named " + petName + "was last vaccinated on " + year + "/" + month + "/" + day ;
        
        
    }
    
}
