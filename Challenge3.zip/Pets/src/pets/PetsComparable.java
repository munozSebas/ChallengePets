/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pets;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;

/**
@author 6306841
@Due date: 2/21/22

*/
/**
 *
 * 
 */
// This is the driver class because it has MAIN in it.
public class PetsComparable {

   /**
*
* Description: Here we declare out array, so it can be throughout the class, it will
* carry 10 elements. We name it myPets.

*/
    // Here we are refrencing our pet class
    public Pets myPets [] = new Pets [10];
     /**
*
* Description: This is our main method where we will declare, the methods we want to run.
*
* @throws  To avoid any file errors we throw IOException
*/
   
    public static void main(String[] args) throws IOException{
    
        PetsComparable newPC =  new PetsComparable();

        newPC.newPets();
        newPC.sortByAge();
        System.out.println("OLDEST & YOUNGEST RECORD (ASCENDING): " );
        newPC.printAge(); 
        newPC.sortByVaccDate();
        System.out.println("\n" + "RECORDS OF VACCINATION DATE (ASCENDING)" );
        newPC.printPets();
        
    }
    
    
    /**
*
* Description: Purpose and function of the method.
* @param any parameter passed to the method
* @return any value returned from the method
* @throwsto avoid file error we throw IOException
*/
    
    public void newPets () throws IOException 
    {
        File aFile = new File ("pets.txt");
        
        // this opens the file
        Scanner inFile = new Scanner (aFile);
    
        
       String petName, species, lastName, firstName, email;
       int age, year, month, day;
       int i =0;
       Pets aPets;
       
       
      while (inFile.hasNext() && i < myPets.length)
      {
          // In this process you have to specify
         // which NEXT variable is going to be used
          
          petName = inFile.next();
          species = inFile.next();
          age = inFile.nextInt();
          year = inFile.nextInt();
          month = inFile.nextInt();
          day = inFile.nextInt();
          lastName = inFile.next();
          firstName = inFile.next();
          email = inFile.next();
          
          Pets aPet =  new Pets (petName, species, age, year, month, day, lastName, firstName, email);
          myPets [i] = aPet;
          i++;
      }
       
       inFile.close();
              
     }
    
    /**
*
* Description: We use this method so we can sort our vaccination dates
* no throws, param, returns.
*/ 
    public void sortByVaccDate()
    {
        
        Arrays.sort (myPets, new CompareByVacc());
        
    }
    
   /**
*
* Description: We want to now print the array we have created, so now with this
* it it outputted and sorted because of the prior sorts.
* No param, return or throws.
* 
* 
*/ 
    public void printPets()
    {
        
        for (int i = 0; i < myPets.length; i++)
        {
            System.out.println (myPets[i]);
        }
            
    }
    
    /**
*
* Description: This method allows us so we properly sort the age, from our array.
* 
* 
*/
    public void sortByAge()
    {
       
    Arrays.sort (myPets);
   
    }   
    
    /**
*
* Description: To not call our toString, we use our getters, so we can create 
* new lines to specifically get Age and Name, which is not stated in our toString. 
* 
*/
    public void printAge()
    {

      System.out.println("This youngest pet in our record is  " + myPets[0].getPetName() + " and is " + myPets[0].getAge() + " year old");
      System.out.println("This oldest pet in our record is  " + myPets[9].getPetName() + " and is " + myPets[9].getAge() + " year old");
 
    }
    
   
    
    
    
    
   }
