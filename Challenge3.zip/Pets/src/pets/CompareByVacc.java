/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pets;
import java.util.Comparator;

/**
 *
 *
 */
/**
@author 6306841
@Due date: 2/21/22

*/

/**
*
* Description: The purpose of this method/class is so we can sort the Vaccinated date, by using an if else method for year, month and day.
* We are implementing the comparator and adding the use of Pets.java 
* so that we can the getters declared in it.
* @param: we use the getters from Pets.java
* @return: we wish to return this in ascending order so we return in order from 1,-1, and 0
* @throws None
*/

public class CompareByVacc implements Comparator <Pets> {
    
     public int compare(Pets pet1, Pets pet2)
    {
        if (pet1.getYear() > pet2.getYear())
        {
            return 1;
        }
        else if (pet1.getYear() < pet2.getYear())
        {
            return -1;
        }
        else
        {
          
            if (pet1.getMonth() > pet2.getMonth())
        {
            return 1;
        }
             else if (pet1.getMonth() < pet2.getMonth())
        {
            return -1;
        }
           
        }
        if (pet1.getDay() > pet2.getDay())
        {
            return 1;
        }
        else if (pet1.getDay() < pet2.getDay())
        {
            return -1;
        }
        else
        {
            return 0;
        }
    }
    
// add more if else

    
}
